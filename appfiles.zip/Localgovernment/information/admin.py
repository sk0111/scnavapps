from django.contrib import admin
from .models import Job, Tender, Project, Notice, Report
# Register your models here.

admin.site.register(Job)
admin.site.register(Tender)
admin.site.register(Project)
admin.site.register(Notice)
admin.site.register(Report)
