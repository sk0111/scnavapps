from django.db import models

# Create your models here.

from django.contrib.auth.models import User

# Create your models here.
class Job(models.Model):
    logo = models.ImageField(upload_to='images/')
    company_name = models.CharField(max_length=100)
    position_name = models.CharField(max_length=100)
    text_description = models.TextField()
    location = models.CharField(max_length=100)
    deadline = models.DateField()
    min_age = models.IntegerField()
    max_age = models.IntegerField()
    salary = models.IntegerField()
    n_openings = models.IntegerField()
    creater = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return '{}{}{}{}{}{}'.format(self.logo, self.company_name, self.position_name, self.text_description, self.location, self.deadline)


class Tender(models.Model):
    logo = models.ImageField(upload_to='images/')
    company_name = models.CharField(max_length=100)
    text_description = models.TextField()
    location = models.CharField(max_length=100)
    deadline = models.DateField()
    tender_details = models.FileField(upload_to='images/', default='images/logo.png')
    creater = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return '{}{}{}{}{}'.format(self.logo, self.company_name, self.text_description, self.location, self.deadline, self.tender_details)

class Project(models.Model):
    logo = models.ImageField(upload_to='images/')
    company_name = models.CharField(max_length=100)
    contractor = models.CharField(max_length=100)
    text_description = models.TextField()
    location = models.CharField(max_length=100)
    date_started = models.DateField()
    deadline = models.DateField()
    project_details = models.FileField(upload_to='images/')
    creater = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return '{}{}{}{}{}{}{}{}'.format(self.logo, self.company_name, self.contractor, self.text_description, self.location, self.date_started, self.deadline, self.project_details)

class Notice(models.Model):
    logo = models.ImageField(upload_to='images/')
    company_name = models.CharField(max_length=100)
    location = models.CharField(max_length=100)
   # department = models.CharField(max_length=100)
    date_posted = models.DateField()
    notice_files = models.FileField(upload_to='images/')
    creater = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return '{}{}{}{}{}'.format(self.logo, self.company_name, self.location, self.date_posted, self.notice_files)

class Report(models.Model):
    logo = models.ImageField(upload_to='images/')
    company_name = models.CharField(max_length=100)
    report_name = models.CharField(max_length=100)
    report_description = models.TextField()
    location = models.CharField(max_length=100)
    date_posted = models.DateField()
    report_files = models.FileField(upload_to='images/')
    creater = models.ForeignKey(User, on_delete=models.CASCADE)

    def __str__(self):
        return '{}{}{}{}{}{}{}'.format(self.logo, self.company_name, self.report_name, self.report_description, self.location, self.date_posted, self.report_files)