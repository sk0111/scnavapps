from django.shortcuts import render
from django.views import View
from .models import Job, Tender, Project, Notice, Report

# Create your views here.
def Index(request):
    return render(request, 'information/index.html')

def Jobs(request):
    data = Job.objects.all()
    return render(request, 'information/job.html', {'data': data})


def Tenders(request):
    data1 = Tender.objects.all()
    return render(request, 'information/tender.html', {'data1':data1})

def Projects(request):
    data2 = Project.objects.all()
    return render(request, 'information/project.html', {'data2':data2})

def Notices(request):
    data3 = Notice.objects.all()
    return render(request, 'information/notice.html', {'data3':data3})

def Reports(request):
    data4 = Report.objects.all()
    return render(request, 'information/report.html', {'data4':data4})

